var config = require("./webpack-dist.config.js")

module.exports = config
